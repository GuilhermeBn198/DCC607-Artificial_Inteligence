# questão da mochila usando algoritmos genéticos

## feito com base no vídeo:
[veja o vídeo de explicação do algoritmo feito pelo Frederico Bender da FURG](https://www.youtube.com/watch?v=fC4mDO3RGQ8)

[veja o link do repositório dele](https://github.com/FredericoBender/Algoritmo-Genetico-Problema-da-Mochila/blob/main/genetic2020.py)
## caracteristicas do algoritmo implementado
- este algoritmo foi implementado e pensado por Bender e seus companheiros, dito isso, tudo nele é propriedade do mesmo. Houve uma tentativa de apenas me basear na linha de pensamento do mesmo, mas ao tentar implementar acabou dando errado, eu ñ tive mais paciência de fazer sozinho e recorri ao algoritmo dele.
- apesar da alegação supracitada, eu entendo o código, visto que bender faz a lógica da genética para poder percorrer as gerações adaptando os numeros e selecionando os melhores resultados. Tanto é que se observarmos o grafico que é impresso no final da execução do algoritmo, podemos observar que a partir de 20 gerações o algoritmo começa a se estabilizar, chegando nas melhores soluções possíveis